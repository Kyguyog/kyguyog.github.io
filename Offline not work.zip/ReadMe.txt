IF YOU DOWNLOADED FILES open index.html if needed select open with your browser

Go to https://kyguyog.github.io/ to open online/no download version Both offline and online have no ads and no fullscreen 30 sec timer

***I just noticed that right now you do have to be online for the offline one I will try to fix that soon probably this week***

Only Keyboards work!

W, A, S, D, Space are the reqired keys

Disclaimer: I only edited the code I did not make it I got the code from hoodamath
